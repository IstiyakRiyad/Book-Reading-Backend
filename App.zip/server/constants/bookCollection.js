module.exports = {
    week: 'এই সপ্তাহের বই',
    bestSeller: 'বেস্টসেলার',
    popular: 'জনপ্রিয় বই',
    selective: 'নির্বাচিত বই',
    favourite: 'পছন্দের বই',
    newPublished: 'নতুন প্রকাশিত',
    upcoming: 'শীগ্রই আসছে'
};