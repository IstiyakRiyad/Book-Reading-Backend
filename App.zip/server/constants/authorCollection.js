module.exports = {
    popularAuthor: 'জনপ্রিয় লেখক'
};