module.exports = {
    publisher: 'প্রকাশক'
};