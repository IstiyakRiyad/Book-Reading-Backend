module.exports = {
    biography: 'জীবনী',
    scienceFiction: 'সায়েন্স ফিকশন',
    childHistory: 'শিশু সাহিত্য',
    nonFiction: 'নন-ফিকশন',
    fiction: 'ফিকশন',
    translated: 'অনুবাদ',
    poem: 'কবিতা',
    novel: 'উপন্যাস',
    religion: 'ধর্মীয়',
    history: 'ইতিহাস'
};